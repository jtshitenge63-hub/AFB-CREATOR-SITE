# AFB Creator – site web (conditions d'utilisation et politique de confidentialité)

Pages statiques en français (racine) et en anglais (`/en/`).
Avant de publier, remplacer l'adresse de contact :

    grep -rl EMAIL_CONTACT_A_REMPLACER . | xargs sed -i 's/EMAIL_CONTACT_A_REMPLACER/votre@adresse.com/g'
